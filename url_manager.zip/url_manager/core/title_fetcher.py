from __future__ import annotations

import re
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup


_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) URLManager/1.0"


def fetch_title(url: str, timeout_sec: float = 5.0) -> str:
    """URLからHTMLタイトルを取得する。失敗時は空文字を返す。"""
    return fetch_preview(url, timeout_sec=timeout_sec).get("title", "")


def fetch_preview(url: str, timeout_sec: float = 5.0) -> dict[str, str]:
    """URLからプレビュー情報（title/description/image_url）を取得する。
    失敗した要素は空文字。
    """
    url = (url or "").strip()
    if not url:
        return {"title": "", "description": "", "image_url": ""}

    try:
        resp = requests.get(url, timeout=timeout_sec, headers={"User-Agent": _USER_AGENT})
        ctype = (resp.headers.get("Content-Type") or "").lower()
        if "text/html" not in ctype and "application/xhtml" not in ctype:
            return {"title": "", "description": "", "image_url": ""}

        resp.encoding = resp.apparent_encoding or resp.encoding
        soup = BeautifulSoup(resp.text, "html.parser")

        def meta(prop: str) -> str:
            tag = soup.find("meta", property=prop)
            if tag and tag.get("content"):
                return str(tag.get("content")).strip()
            return ""

        def meta_name(name: str) -> str:
            tag = soup.find("meta", attrs={"name": name})
            if tag and tag.get("content"):
                return str(tag.get("content")).strip()
            return ""

        # title: og:title -> twitter:title -> <title>
        title = meta("og:title") or meta_name("twitter:title") or ""
        if not title:
            title = soup.title.string if soup.title and soup.title.string else ""
        title = re.sub(r"\s+", " ", (title or "")).strip()[:200]

        # description
        desc = meta("og:description") or meta_name("description") or meta_name("twitter:description") or ""
        desc = re.sub(r"\s+", " ", (desc or "")).strip()[:400]

        # image url
        img = meta("og:image") or meta_name("twitter:image") or ""
        img = (img or "").strip()
        if img:
            img = urljoin(url, img)

        return {"title": title, "description": desc, "image_url": img}
    except Exception:
        return {"title": "", "description": "", "image_url": ""}
