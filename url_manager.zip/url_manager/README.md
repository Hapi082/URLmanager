# URL Manager (Final)

## セットアップ
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 起動
```bash
python main.py
```

## できること（MVP + SHOULD相当）
- Excel(.xlsx)を開く（存在しない場合は自動的にスキーマ補完）
- URL一覧表示（urlsシート）
- URL追加（＋）→ Excelへ保存 → 即時反映
- URL編集 / 削除（右クリックメニュー）
- ダブルクリックでURLを既定ブラウザで開く
- タグ管理（tagボタン）: 追加/削除（削除時はURL側タグ自動解除）
- タグフィルタ（tag filter）: OR/AND切替 + 複数選択 + 全解除
- 検索（URL/タグ）

## Excelスキーマ
- urls: id, url, created_at, tags, title, note
- tags: name, created_at

## 注意
- Excelファイルが別アプリで開かれていると保存時にエラーになります。
  その場合はExcelを閉じて再度お試しください。

- URLの下に作成日(YYYY-MM-DD)を表示
- 下部の「編集」「削除」ボタンでUI上から操作可能（右クリックでも可）

- 下部に GO ボタンを追加（選択中URLを既定ブラウザで開く）

- ★お気に入り（一覧右端の星で切替）
- 利用数カウント（GO/ダブルクリックで+1）
- 並び替え（お気に入り/追加日/利用数/URL）＋昇順/降順切替

- カスタム順（ドラッグ&ドロップで並び替え → 自動保存）

- URL追加/編集時にページタイトルを自動取得して保存（一覧でURLの上に表示）

- URL行にカーソルを合わせると画像付きプレビューを表示（og:image / description を利用。未取得なら自動取得してExcelへ保存）
