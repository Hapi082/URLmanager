from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QPushButton, QRadioButton, QButtonGroup
)


class FilterDialog(QDialog):
    def __init__(
        self,
        all_tags: list[str],
        initial_mode: str = "OR",
        initial_selected: list[str] | None = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("タグフィルタ")
        self.setModal(True)
        self.setMinimumWidth(520)

        self._mode = (initial_mode or "OR").upper()
        self._selected = initial_selected or []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        layout.addWidget(QLabel("モード"))
        self.rb_or = QRadioButton("OR（いずれか含む）")
        self.rb_and = QRadioButton("AND（すべて含む）")
        self.rb_or.setChecked(self._mode != "AND")
        self.rb_and.setChecked(self._mode == "AND")
        layout.addWidget(self.rb_or)
        layout.addWidget(self.rb_and)

        self.group = QButtonGroup(self)
        self.group.addButton(self.rb_or)
        self.group.addButton(self.rb_and)

        layout.addWidget(QLabel("タグ（複数選択可）"))
        self.list_tags = QListWidget()
        self.list_tags.setSelectionMode(QListWidget.MultiSelection)
        for t in all_tags:
            item = QListWidgetItem(t)
            self.list_tags.addItem(item)
            if t in self._selected:
                item.setSelected(True)
        layout.addWidget(self.list_tags, stretch=1)

        btns = QHBoxLayout()
        self.btn_clear = QPushButton("全解除")
        self.btn_clear.clicked.connect(self._clear)
        btns.addWidget(self.btn_clear)

        btns.addStretch(1)

        self.btn_cancel = QPushButton("戻る")
        self.btn_cancel.clicked.connect(self.reject)
        btns.addWidget(self.btn_cancel)

        self.btn_apply = QPushButton("適用")
        self.btn_apply.clicked.connect(self.accept)
        btns.addWidget(self.btn_apply)

        layout.addLayout(btns)

    def _clear(self) -> None:
        for i in range(self.list_tags.count()):
            self.list_tags.item(i).setSelected(False)

    def result_data(self) -> tuple[str, list[str]]:
        mode = "AND" if self.rb_and.isChecked() else "OR"
        selected = [i.text() for i in self.list_tags.selectedItems()]
        return mode, selected
