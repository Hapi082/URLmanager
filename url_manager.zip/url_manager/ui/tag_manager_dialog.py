from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QLabel, QLineEdit, QPushButton, QMessageBox
)

from core.validator import normalize_tag


class TagManagerDialog(QDialog):
    """タグ管理（追加・削除）"""

    def __init__(self, repo, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("タグ管理")
        self.setModal(True)
        self.setMinimumWidth(480)

        self.repo = repo

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        layout.addWidget(QLabel("タグ一覧"))
        self.list_tags = QListWidget()
        layout.addWidget(self.list_tags, stretch=1)

        row = QHBoxLayout()
        self.edit_new = QLineEdit()
        self.edit_new.setPlaceholderText("新しいタグ名")
        row.addWidget(self.edit_new)

        self.btn_add = QPushButton("追加")
        self.btn_add.clicked.connect(self.add_tag)
        row.addWidget(self.btn_add)
        layout.addLayout(row)

        row2 = QHBoxLayout()
        self.btn_delete = QPushButton("削除")
        self.btn_delete.clicked.connect(self.delete_selected)
        row2.addWidget(self.btn_delete)

        row2.addStretch(1)
        self.btn_close = QPushButton("閉じる")
        self.btn_close.clicked.connect(self.accept)
        row2.addWidget(self.btn_close)
        layout.addLayout(row2)

        self.refresh()

    def refresh(self) -> None:
        self.list_tags.clear()
        for t in self.repo.load_tags():
            self.list_tags.addItem(QListWidgetItem(t))

    def add_tag(self) -> None:
        name = normalize_tag(self.edit_new.text())
        if not name:
            QMessageBox.warning(self, "入力エラー", "タグ名を入力してください。")
            return
        try:
            self.repo.add_tag(name)
        except Exception as e:
            QMessageBox.critical(self, "エラー", str(e))
            return
        self.edit_new.clear()
        self.refresh()

    def delete_selected(self) -> None:
        items = self.list_tags.selectedItems()
        if not items:
            QMessageBox.information(self, "削除", "削除するタグを選択してください。")
            return
        name = items[0].text()

        ret = QMessageBox.question(
            self,
            "削除確認",
            f"タグ「{name}」を削除しますか？\n"
            "このタグはURLから自動的に外されます。",
        )
        if ret != QMessageBox.StandardButton.Yes:
            return

        try:
            self.repo.delete_tag(name)
        except Exception as e:
            QMessageBox.critical(self, "エラー", str(e))
            return

        self.refresh()
