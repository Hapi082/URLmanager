from __future__ import annotations
from core.models import UrlItem


def match(item: UrlItem, selected_tags: list[str], mode: str) -> bool:
    if not selected_tags:
        return True

    s = {t for t in selected_tags if t}
    tset = set(item.tags)

    mode = (mode or "OR").upper()
    if mode == "AND":
        return s.issubset(tset)
    # default OR
    return len(s & tset) > 0


def apply(items: list[UrlItem], selected_tags: list[str], mode: str) -> list[UrlItem]:
    return [it for it in items if match(it, selected_tags, mode)]
