from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QListWidget


class DraggableListWidget(QListWidget):
    """InternalMove の並び替えを検知して通知する QListWidget。"""

    order_changed = Signal()
    hover_left = Signal()

    def dropEvent(self, event) -> None:
        super().dropEvent(event)
        self.order_changed.emit()

    def leaveEvent(self, event) -> None:
        super().leaveEvent(event)
        self.hover_left.emit()
