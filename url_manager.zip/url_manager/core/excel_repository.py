from __future__ import annotations

from pathlib import Path
import uuid
from openpyxl import Workbook, load_workbook
from openpyxl.worksheet.worksheet import Worksheet

from core.models import UrlItem, parse_tags, format_tags, now_iso


class ExcelRepository:
    """Excel(.xlsx)を簡易DBとして扱うRepository。

    - urls / tags シートの生成・読み込み・更新・削除
    - タグ削除時のURL側タグ自動解除
    - favorite / usage_count / custom_order / title / preview_cache をサポート
    """

    URL_SHEET = "urls"
    TAG_SHEET = "tags"

    URL_HEADERS = [
        "id", "url", "created_at", "tags",
        "title", "note",
        "favorite", "usage_count", "custom_order",
        "preview_desc", "preview_image_url",
    ]
    TAG_HEADERS = ["name", "created_at"]

    def __init__(self, path: str):
        self.path = Path(path)
        if not self.path.exists():
            self._create_new()
        else:
            self._ensure_schema()

    # --------- Public: Read ---------

    def load_urls(self) -> list[UrlItem]:
        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        rows = list(ws.iter_rows(values_only=True))
        if len(rows) <= 1:
            return []

        header = [str(h) if h is not None else "" for h in rows[0]]
        col = {name: header.index(name) for name in header}

        def get(row, name, default=None):
            i = col.get(name)
            if i is None or i >= len(row):
                return default
            v = row[i]
            return default if v is None else v

        out: list[UrlItem] = []
        for row in rows[1:]:
            url = get(row, "url", "")
            if not url:
                continue

            fav = get(row, "favorite", 0)
            use = get(row, "usage_count", 0)
            order = get(row, "custom_order", 0)

            try:
                fav_i = int(fav)
            except Exception:
                fav_i = 0
            try:
                use_i = int(use)
            except Exception:
                use_i = 0
            try:
                order_i = int(order)
            except Exception:
                order_i = 0

            out.append(UrlItem(
                id=str(get(row, "id", "") or ""),
                url=str(url),
                created_at=str(get(row, "created_at", "") or ""),
                tags=parse_tags(get(row, "tags", "")),
                title=str(get(row, "title", "") or ""),
                note=str(get(row, "note", "") or ""),
                favorite=1 if fav_i else 0,
                usage_count=max(0, use_i),
                custom_order=order_i,
                preview_desc=str(get(row, "preview_desc", "") or ""),
                preview_image_url=str(get(row, "preview_image_url", "") or ""),
            ))
        return out

    def load_tags(self) -> list[str]:
        wb = load_workbook(self.path)
        ws = wb[self.TAG_SHEET]
        rows = list(ws.iter_rows(values_only=True))
        if len(rows) <= 1:
            return []

        header = [str(h) if h is not None else "" for h in rows[0]]
        try:
            name_i = header.index("name")
        except ValueError:
            return []

        names: list[str] = []
        for row in rows[1:]:
            if row and name_i < len(row) and row[name_i]:
                names.append(str(row[name_i]).strip())

        seen = set()
        out = []
        for n in names:
            if not n or n in seen:
                continue
            seen.add(n)
            out.append(n)
        return out

    # --------- Public: Write URLs ---------

    def add_url(
        self,
        url: str,
        tags: list[str],
        title: str = "",
        preview_desc: str = "",
        preview_image_url: str = "",
    ) -> UrlItem:
        url = (url or "").strip()
        if not url:
            raise ValueError("URL is required.")

        self._ensure_tags_exist(tags)

        max_order = self.get_max_custom_order()
        item = UrlItem(
            id=str(uuid.uuid4()),
            url=url,
            created_at=now_iso(),
            tags=[t.strip() for t in tags if t and t.strip()],
            title=(title or "").strip(),
            note="",
            favorite=0,
            usage_count=0,
            custom_order=max_order + 1,
            preview_desc=(preview_desc or "").strip(),
            preview_image_url=(preview_image_url or "").strip(),
        )

        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        ws.append([
            item.id,
            item.url,
            item.created_at,
            format_tags(item.tags),
            item.title,
            item.note,
            item.favorite,
            item.usage_count,
            item.custom_order,
            item.preview_desc,
            item.preview_image_url,
        ])
        self._save_workbook(wb)
        return item

    def update_url(self, item_id: str, new_url: str, new_tags: list[str]) -> None:
        new_url = (new_url or "").strip()
        if not new_url:
            raise ValueError("URL is required.")

        self._ensure_tags_exist(new_tags)

        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        header = self._read_header(ws)
        col = {name: header.index(name) + 1 for name in header}

        id_col = col.get("id")
        if not id_col:
            raise ValueError("Excel schema error: id column missing.")

        for r in range(2, ws.max_row + 1):
            if str(ws.cell(r, id_col).value or "") == item_id:
                if "url" in col:
                    ws.cell(r, col["url"]).value = new_url
                if "tags" in col:
                    ws.cell(r, col["tags"]).value = format_tags(new_tags)
                self._save_workbook(wb)
                return

        raise KeyError(f"URL id not found: {item_id}")

    def update_preview(self, item_id: str, title: str = "", preview_desc: str = "", preview_image_url: str = "") -> None:
        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        header = self._read_header(ws)
        col = {name: header.index(name) + 1 for name in header}
        id_col = col.get("id")
        if not id_col:
            raise ValueError("Excel schema error: id column missing.")

        for r in range(2, ws.max_row + 1):
            if str(ws.cell(r, id_col).value or "") == item_id:
                if "title" in col:
                    ws.cell(r, col["title"]).value = (title or "").strip()
                if "preview_desc" in col:
                    ws.cell(r, col["preview_desc"]).value = (preview_desc or "").strip()
                if "preview_image_url" in col:
                    ws.cell(r, col["preview_image_url"]).value = (preview_image_url or "").strip()
                self._save_workbook(wb)
                return
        raise KeyError(f"URL id not found: {item_id}")

    def delete_url(self, item_id: str) -> None:
        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        header = self._read_header(ws)
        col = {name: header.index(name) + 1 for name in header}
        id_col = col.get("id")
        if not id_col:
            raise ValueError("Excel schema error: id column missing.")

        for r in range(ws.max_row, 1, -1):
            if str(ws.cell(r, id_col).value or "") == item_id:
                ws.delete_rows(r, 1)
                self._save_workbook(wb)
                return
        raise KeyError(f"URL id not found: {item_id}")

    def set_favorite(self, item_id: str, favorite: int) -> None:
        favorite = 1 if int(favorite) else 0
        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        header = self._read_header(ws)
        col = {name: header.index(name) + 1 for name in header}
        id_col = col.get("id")
        fav_col = col.get("favorite")
        if not id_col or not fav_col:
            raise ValueError("Excel schema error: id/favorite column missing.")

        for r in range(2, ws.max_row + 1):
            if str(ws.cell(r, id_col).value or "") == item_id:
                ws.cell(r, fav_col).value = favorite
                self._save_workbook(wb)
                return
        raise KeyError(f"URL id not found: {item_id}")

    def increment_usage(self, item_id: str) -> int:
        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        header = self._read_header(ws)
        col = {name: header.index(name) + 1 for name in header}
        id_col = col.get("id")
        use_col = col.get("usage_count")
        if not id_col or not use_col:
            raise ValueError("Excel schema error: id/usage_count column missing.")

        for r in range(2, ws.max_row + 1):
            if str(ws.cell(r, id_col).value or "") == item_id:
                cur = ws.cell(r, use_col).value
                try:
                    cur_i = int(cur or 0)
                except Exception:
                    cur_i = 0
                cur_i += 1
                ws.cell(r, use_col).value = cur_i
                self._save_workbook(wb)
                return cur_i
        raise KeyError(f"URL id not found: {item_id}")

    def get_max_custom_order(self) -> int:
        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        header = self._read_header(ws)
        if "custom_order" not in header:
            return 0
        col = header.index("custom_order") + 1
        m = 0
        for r in range(2, ws.max_row + 1):
            v = ws.cell(r, col).value
            try:
                m = max(m, int(v or 0))
            except Exception:
                pass
        return m

    def set_custom_order(self, ordered_ids: list[str]) -> None:
        wb = load_workbook(self.path)
        ws = wb[self.URL_SHEET]
        header = self._read_header(ws)
        col = {name: header.index(name) + 1 for name in header}
        id_col = col.get("id")
        ord_col = col.get("custom_order")
        if not id_col or not ord_col:
            raise ValueError("Excel schema error: id/custom_order column missing.")

        id_to_row = {}
        for r in range(2, ws.max_row + 1):
            rid = str(ws.cell(r, id_col).value or "")
            if rid:
                id_to_row[rid] = r

        for idx, rid in enumerate(ordered_ids, start=1):
            r = id_to_row.get(rid)
            if r is None:
                continue
            ws.cell(r, ord_col).value = idx

        self._save_workbook(wb)

    # --------- Public: Tags ---------

    def add_tag(self, name: str) -> None:
        name = (name or "").strip()
        if not name:
            raise ValueError("Tag name is required.")

        existing = set(self.load_tags())
        if name in existing:
            return

        wb = load_workbook(self.path)
        ws = wb[self.TAG_SHEET]
        ws.append([name, now_iso()])
        self._save_workbook(wb)

    def delete_tag(self, name: str) -> None:
        name = (name or "").strip()
        if not name:
            return

        wb = load_workbook(self.path)

        ws_tags = wb[self.TAG_SHEET]
        header = self._read_header(ws_tags)
        if "name" in header:
            name_col = header.index("name") + 1
            for r in range(ws_tags.max_row, 1, -1):
                if str(ws_tags.cell(r, name_col).value or "").strip() == name:
                    ws_tags.delete_rows(r, 1)

        ws_urls = wb[self.URL_SHEET]
        header_u = self._read_header(ws_urls)
        if "tags" in header_u:
            tags_col = header_u.index("tags") + 1
            for r in range(2, ws_urls.max_row + 1):
                cur = parse_tags(ws_urls.cell(r, tags_col).value)
                if name in cur:
                    cur = [t for t in cur if t != name]
                    ws_urls.cell(r, tags_col).value = format_tags(cur)

        self._save_workbook(wb)

    # --------- Schema / Helpers ---------

    def _create_new(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        wb = Workbook()
        ws = wb.active
        ws.title = self.URL_SHEET
        ws.append(self.URL_HEADERS)

        ws_tags = wb.create_sheet(self.TAG_SHEET)
        ws_tags.append(self.TAG_HEADERS)

        self._save_workbook(wb)

    def _ensure_schema(self) -> None:
        wb = load_workbook(self.path)
        changed = False

        if self.URL_SHEET not in wb.sheetnames:
            ws = wb.create_sheet(self.URL_SHEET)
            ws.append(self.URL_HEADERS)
            changed = True
        else:
            changed |= self._ensure_headers(wb[self.URL_SHEET], self.URL_HEADERS)

        if self.TAG_SHEET not in wb.sheetnames:
            ws = wb.create_sheet(self.TAG_SHEET)
            ws.append(self.TAG_HEADERS)
            changed = True
        else:
            changed |= self._ensure_headers(wb[self.TAG_SHEET], self.TAG_HEADERS)

        if changed:
            self._save_workbook(wb)

    def _ensure_headers(self, ws: Worksheet, headers: list[str]) -> bool:
        if ws.max_row < 1:
            ws.append(headers)
            return True
        cur = [str(c.value) if c.value is not None else "" for c in ws[1]]

        if all(not x for x in cur):
            for i, h in enumerate(headers, start=1):
                ws.cell(1, i).value = h
            return True

        existing = set(cur)
        changed = False
        for h in headers:
            if h not in existing:
                ws.cell(1, ws.max_column + 1).value = h
                changed = True
        return changed

    def _read_header(self, ws: Worksheet) -> list[str]:
        if ws.max_row < 1:
            return []
        return [str(c.value) if c.value is not None else "" for c in ws[1]]

    def _save_workbook(self, wb) -> None:
        try:
            wb.save(self.path)
        except PermissionError as e:
            raise PermissionError(
                "Excelファイルが他のアプリで開かれている可能性があります。"
                "Excelを閉じてから再度お試しください。"
            ) from e

    def _ensure_tags_exist(self, tags: list[str]) -> None:
        tags = [t.strip() for t in tags if t and t.strip()]
        if not tags:
            return
        existing = set(self.load_tags())
        missing = [t for t in tags if t not in existing]
        if not missing:
            return

        wb = load_workbook(self.path)
        ws = wb[self.TAG_SHEET]
        for t in missing:
            ws.append([t, now_iso()])
        self._save_workbook(wb)
