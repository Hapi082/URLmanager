from __future__ import annotations

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel


class PreviewPopup(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.ToolTip | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)

        self.setStyleSheet("""
        QFrame {
            background: white;
            border: 1px solid #cfcfcf;
            border-radius: 10px;
        }
        """)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(6)

        self.lbl_img = QLabel()
        self.lbl_img.setFixedSize(QSize(260, 146))
        self.lbl_img.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_img.setStyleSheet("background:#f3f3f3; border-radius: 8px; color:#888;")
        self.lbl_img.setText("loading...")
        layout.addWidget(self.lbl_img)

        self.lbl_title = QLabel()
        self.lbl_title.setWordWrap(True)
        self.lbl_title.setStyleSheet("font-weight: 700;")
        layout.addWidget(self.lbl_title)

        self.lbl_url = QLabel()
        self.lbl_url.setWordWrap(True)
        self.lbl_url.setStyleSheet("color:#444; font-size: 11px;")
        layout.addWidget(self.lbl_url)

        self.lbl_desc = QLabel()
        self.lbl_desc.setWordWrap(True)
        self.lbl_desc.setStyleSheet("color:#666; font-size: 11px;")
        layout.addWidget(self.lbl_desc)

        self._pixmap: QPixmap | None = None

    def set_content(self, title: str, url: str, desc: str, image_url: str) -> None:
        self.lbl_title.setText(title or "(no title)")
        self.lbl_url.setText(url or "")
        self.lbl_desc.setText(desc or "")
        if image_url:
            self.set_image_placeholder("loading...")
        else:
            self.set_image_placeholder("no image")

    def set_image_placeholder(self, text: str) -> None:
        self._pixmap = None
        self.lbl_img.setPixmap(QPixmap())
        self.lbl_img.setText(text)

    def set_pixmap(self, pixmap: QPixmap | None) -> None:
        if pixmap is None or pixmap.isNull():
            self.set_image_placeholder("no image")
            return
        self._pixmap = pixmap
        scaled = pixmap.scaled(self.lbl_img.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        self.lbl_img.setText("")
        self.lbl_img.setPixmap(scaled)

    def show_at(self, global_pos) -> None:
        # small offset so it doesn't cover the cursor
        x = int(global_pos.x()) + 14
        y = int(global_pos.y()) + 14
        self.move(x, y)
        self.show()
