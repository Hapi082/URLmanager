from __future__ import annotations

import requests
from PySide6.QtCore import QThread, Signal
from PySide6.QtGui import QPixmap

from core.title_fetcher import fetch_preview


class PreviewFetchThread(QThread):
    done = Signal(dict)  # {title, description, image_url}

    def __init__(self, url: str, timeout_sec: float = 5.0):
        super().__init__()
        self.url = url
        self.timeout_sec = timeout_sec

    def run(self) -> None:
        data = fetch_preview(self.url, timeout_sec=self.timeout_sec)
        self.done.emit(data)


class ImageFetchThread(QThread):
    done = Signal(object)  # QPixmap | None

    def __init__(self, image_url: str, timeout_sec: float = 6.0, max_bytes: int = 2_000_000):
        super().__init__()
        self.image_url = image_url
        self.timeout_sec = timeout_sec
        self.max_bytes = max_bytes

    def run(self) -> None:
        try:
            r = requests.get(self.image_url, timeout=self.timeout_sec, stream=True, headers={"User-Agent": "URLManager/1.0"})
            r.raise_for_status()
            data = bytearray()
            for chunk in r.iter_content(chunk_size=8192):
                if not chunk:
                    continue
                data.extend(chunk)
                if len(data) > self.max_bytes:
                    break

            pix = QPixmap()
            ok = pix.loadFromData(bytes(data))
            self.done.emit(pix if ok else None)
        except Exception:
            self.done.emit(None)
