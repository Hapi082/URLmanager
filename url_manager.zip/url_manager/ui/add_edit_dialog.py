from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QPushButton, QMessageBox
)

from core.validator import validate_url


class AddEditDialog(QDialog):
    """URLの追加/編集（共通ダイアログ）"""

    def __init__(
        self,
        available_tags: list[str],
        title: str,
        initial_url: str = "",
        initial_tags: list[str] | None = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(560)

        self._url: str | None = None
        self._tags: list[str] = []

        initial_tags = initial_tags or []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        layout.addWidget(QLabel("URL（必須）"))
        self.edit_url = QLineEdit()
        self.edit_url.setPlaceholderText("https://...")
        self.edit_url.setText(initial_url)
        layout.addWidget(self.edit_url)

        layout.addWidget(QLabel("タグ（複数選択可）"))
        self.list_tags = QListWidget()
        self.list_tags.setSelectionMode(QListWidget.MultiSelection)
        for t in available_tags:
            item = QListWidgetItem(t)
            self.list_tags.addItem(item)
            if t in initial_tags:
                item.setSelected(True)
        layout.addWidget(self.list_tags, stretch=1)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)

        self.btn_cancel = QPushButton("キャンセル")
        self.btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(self.btn_cancel)

        self.btn_save = QPushButton("保存")
        self.btn_save.clicked.connect(self._save)
        btn_row.addWidget(self.btn_save)

        layout.addLayout(btn_row)

        self.edit_url.setFocus()

    def _save(self) -> None:
        url = self.edit_url.text().strip()
        ok, msg = validate_url(url)
        if not ok:
            QMessageBox.warning(self, "入力エラー", msg)
            return

        tags = [i.text().strip() for i in self.list_tags.selectedItems()]
        self._url = url
        self._tags = [t for t in tags if t]
        self.accept()

    def result_data(self) -> tuple[str | None, list[str]]:
        return self._url, self._tags
