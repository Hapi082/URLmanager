from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List


@dataclass
class UrlItem:
    id: str
    url: str
    created_at: str
    tags: List[str]
    title: str = ""
    note: str = ""
    favorite: int = 0          # 0 or 1
    usage_count: int = 0       # number of times opened via GO / double-click
    custom_order: int = 0      # for manual ordering (smaller = upper)
    preview_desc: str = ""     # meta/og description cache
    preview_image_url: str = ""# og:image cache


def parse_tags(tag_str: str | None) -> list[str]:
    if not tag_str:
        return []
    return [t.strip() for t in str(tag_str).split(";") if t and str(t).strip()]


def format_tags(tags: list[str]) -> str:
    seen = set()
    out = []
    for t in tags:
        t = t.strip()
        if not t or t in seen:
            continue
        seen.add(t)
        out.append(t)
    return ";".join(out)


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")
