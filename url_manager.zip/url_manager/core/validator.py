from __future__ import annotations

import re

_URL_RE = re.compile(r"^https?://", re.IGNORECASE)


def validate_url(url: str) -> tuple[bool, str]:
    url = (url or "").strip()
    if not url:
        return False, "URLを入力してください。"
    if not _URL_RE.match(url):
        return False, "URLは http:// または https:// から始めてください。"
    return True, ""


def normalize_tag(name: str) -> str:
    return (name or "").strip()
