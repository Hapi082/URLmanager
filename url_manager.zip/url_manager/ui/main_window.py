from __future__ import annotations

import webbrowser
from datetime import datetime
from PySide6.QtCore import Qt, QPoint, QSize, Signal
from PySide6.QtGui import QCursor
from PySide6.QtWidgets import (
    QWidget, QMainWindow, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QListWidgetItem, QFileDialog, QMessageBox,
    QLineEdit, QMenu, QDialog, QSizePolicy, QComboBox, QToolButton, QAbstractItemView
)

from core.excel_repository import ExcelRepository
from core.filter_logic import apply as apply_filter
from core.models import UrlItem
from core.title_fetcher import fetch_preview

from ui.add_edit_dialog import AddEditDialog
from ui.tag_manager_dialog import TagManagerDialog
from ui.filter_dialog import FilterDialog
from ui.draggable_list import DraggableListWidget
from ui.preview_popup import PreviewPopup
from ui.preview_workers import ImageFetchThread, PreviewFetchThread


def _format_date(created_at: str) -> str:
    s = (created_at or "").strip()
    if not s:
        return ""
    try:
        dt = datetime.fromisoformat(s)
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return s[:10]


class UrlListItemWidget(QWidget):
    """タイトル → URL → メタ（作成日/利用数） + 右端に★（お気に入り）"""

    favorite_toggled = Signal(str, int)  # (id, new_value)

    def __init__(
        self,
        item_id: str,
        title_text: str,
        url_text: str,
        meta_text: str,
        is_favorite: bool,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._id = item_id

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(8)

        left = QVBoxLayout()
        left.setSpacing(2)

        self.lbl_title = QLabel(title_text or "(no title)")
        self.lbl_title.setStyleSheet("font-weight: 600;")
        self.lbl_title.setWordWrap(True)
        self.lbl_title.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.lbl_url = QLabel(url_text)
        self.lbl_url.setWordWrap(True)
        self.lbl_url.setStyleSheet("color: #222;")
        self.lbl_url.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.lbl_meta = QLabel(meta_text)
        self.lbl_meta.setStyleSheet("color: #666; font-size: 11px;")
        self.lbl_meta.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        left.addWidget(self.lbl_title)
        left.addWidget(self.lbl_url)
        if meta_text:
            left.addWidget(self.lbl_meta)

        layout.addLayout(left, stretch=1)

        self.btn_star = QToolButton()
        self.btn_star.setText("★" if is_favorite else "☆")
        self.btn_star.setToolTip("お気に入り")
        self.btn_star.setAutoRaise(True)
        self.btn_star.clicked.connect(self._toggle)
        layout.addWidget(self.btn_star, alignment=Qt.AlignmentFlag.AlignTop)

    def _toggle(self) -> None:
        new_val = 0 if self.btn_star.text() == "★" else 1
        self.btn_star.setText("★" if new_val else "☆")
        self.favorite_toggled.emit(self._id, new_val)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("URL Manager")
        self.setMinimumSize(1060, 760)

        self.repo: ExcelRepository | None = None
        self.all_items: list[UrlItem] = []

        # filter/search/sort state
        self.filter_mode: str = "OR"
        self.filter_tags: list[str] = []
        self.search_text: str = ""

        self.sort_key: str = "favorite"  # favorite | custom | created_at | usage_count | url
        self.sort_desc: bool = True      # for created_at / usage_count / url

        # hover preview
        self.preview = PreviewPopup(self)
        self.preview.hide()
        self._hover_token = 0
        self._img_thread: ImageFetchThread | None = None
        self._preview_thread: PreviewFetchThread | None = None
        self._hovered_id: str | None = None

        root = QWidget()
        self.setCentralWidget(root)
        self.statusBar().showMessage("Ready")

        outer = QHBoxLayout(root)
        outer.setContentsMargins(16, 16, 16, 16)
        outer.setSpacing(12)

        # Left
        self.btn_tag = QPushButton("tag")
        self.btn_tag.setFixedWidth(110)
        self.btn_tag.clicked.connect(self.open_tag_manager)
        outer.addWidget(self.btn_tag, alignment=Qt.AlignmentFlag.AlignTop)

        # Center
        center = QVBoxLayout()
        center.setSpacing(10)
        outer.addLayout(center, stretch=1)

        # Top bar
        top = QVBoxLayout()
        top.setSpacing(6)

        row1 = QHBoxLayout()
        self.lbl_excel = QLabel("Excel: (not selected)")
        self.lbl_excel.setStyleSheet("font-weight: bold;")
        row1.addWidget(self.lbl_excel)
        row1.addStretch(1)

        self.btn_open_excel = QPushButton("Excelを開く")
        self.btn_open_excel.clicked.connect(self.open_excel)
        row1.addWidget(self.btn_open_excel)
        top.addLayout(row1)

        row2 = QHBoxLayout()
        self.lbl_filter = QLabel("Filter: (none)")
        row2.addWidget(self.lbl_filter)
        row2.addStretch(1)

        self.search = QLineEdit()
        self.search.setPlaceholderText("検索（タイトル / URL / タグ）")
        self.search.textChanged.connect(self.on_search_changed)
        self.search.setFixedWidth(380)
        row2.addWidget(self.search)
        top.addLayout(row2)

        # Sort row
        row3 = QHBoxLayout()
        row3.addWidget(QLabel("並び替え"))
        self.cmb_sort = QComboBox()
        self.cmb_sort.addItem("カスタム順（ドラッグで並び替え）", "custom")
        self.cmb_sort.addItem("お気に入り順", "favorite")
        self.cmb_sort.addItem("追加日順", "created_at")
        self.cmb_sort.addItem("利用数順", "usage_count")
        self.cmb_sort.addItem("URL順", "url")
        self.cmb_sort.currentIndexChanged.connect(self.on_sort_changed)
        row3.addWidget(self.cmb_sort)

        self.btn_order = QPushButton("降順")
        self.btn_order.setFixedWidth(64)
        self.btn_order.clicked.connect(self.toggle_sort_order)
        row3.addWidget(self.btn_order)

        self.lbl_drag_hint = QLabel("")
        self.lbl_drag_hint.setStyleSheet("color:#666; font-size: 11px;")
        row3.addWidget(self.lbl_drag_hint)

        row3.addStretch(1)
        top.addLayout(row3)

        center.addLayout(top)

        # List (draggable)
        self.list_urls = DraggableListWidget()
        self.list_urls.setAlternatingRowColors(True)
        self.list_urls.itemDoubleClicked.connect(self.open_selected_in_browser)
        self.list_urls.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list_urls.customContextMenuRequested.connect(self.show_context_menu)
        self.list_urls.itemSelectionChanged.connect(self.on_selection_changed)
        self.list_urls.order_changed.connect(self.on_custom_order_changed)
        self.list_urls.hover_left.connect(self.hide_preview)

        # Hover tracking
        self.list_urls.setMouseTracking(True)
        self.list_urls.viewport().setMouseTracking(True)
        self.list_urls.itemEntered.connect(self.on_item_hovered)

        center.addWidget(self.list_urls, stretch=1)

        # Bottom actions
        bottom = QHBoxLayout()

        self.btn_edit = QPushButton("編集")
        self.btn_edit.setEnabled(False)
        self.btn_edit.clicked.connect(self.edit_selected)
        bottom.addWidget(self.btn_edit)

        self.btn_delete = QPushButton("削除")
        self.btn_delete.setEnabled(False)
        self.btn_delete.clicked.connect(self.delete_selected)
        bottom.addWidget(self.btn_delete)

        self.btn_go = QPushButton("GO")
        self.btn_go.setEnabled(False)
        self.btn_go.clicked.connect(self.open_selected_in_browser)
        bottom.addWidget(self.btn_go)

        bottom.addStretch(1)

        self.btn_add = QPushButton("＋")
        self.btn_add.setFixedSize(52, 36)
        self.btn_add.clicked.connect(self.add_url)
        bottom.addWidget(self.btn_add)

        center.addLayout(bottom)

        # Right
        self.btn_filter = QPushButton("tag filter")
        self.btn_filter.setFixedWidth(110)
        self.btn_filter.clicked.connect(self.open_filter)
        outer.addWidget(self.btn_filter, alignment=Qt.AlignmentFlag.AlignTop)

        self.render_empty_hint()
        self.update_sort_ui()

    # ---------- hover preview ----------

    def hide_preview(self) -> None:
        self._hovered_id = None
        self.preview.hide()
        self._hover_token += 1  # invalidate pending results

    def on_item_hovered(self, lw_item: QListWidgetItem) -> None:
        item_id = lw_item.data(Qt.ItemDataRole.UserRole)
        if not item_id:
            return
        it = next((x for x in self.all_items if x.id == item_id), None)
        if it is None:
            return

        self._hovered_id = item_id
        self._hover_token += 1
        token = self._hover_token

        # show popup immediately with cached data
        self.preview.set_content(it.title, it.url, it.preview_desc, it.preview_image_url)
        self.preview.show_at(QCursor.pos())

        # If preview cache missing, fetch in background and save to Excel
        if (not it.preview_desc) or (not it.preview_image_url) or (not it.title):
            if self.repo is not None:
                self._preview_thread = PreviewFetchThread(it.url)
                self._preview_thread.done.connect(lambda data: self._on_preview_fetched(token, item_id, data))
                self._preview_thread.start()

        # load image (cached URL)
        if it.preview_image_url:
            self._img_thread = ImageFetchThread(it.preview_image_url)
            self._img_thread.done.connect(lambda pix: self._on_image_fetched(token, pix))
            self._img_thread.start()

    def _on_preview_fetched(self, token: int, item_id: str, data: dict) -> None:
        if token != self._hover_token:
            return
        if self.repo is None:
            return

        title = data.get("title", "")
        desc = data.get("description", "")
        img = data.get("image_url", "")

        try:
            self.repo.update_preview(item_id, title=title, preview_desc=desc, preview_image_url=img)
        except Exception:
            pass

        # refresh internal list, keep popup for current hovered item
        self.reload_from_repo()
        it = next((x for x in self.all_items if x.id == item_id), None)
        if it is None or item_id != self._hovered_id:
            return
        self.preview.set_content(it.title, it.url, it.preview_desc, it.preview_image_url)

        if it.preview_image_url:
            self._img_thread = ImageFetchThread(it.preview_image_url)
            self._img_thread.done.connect(lambda pix: self._on_image_fetched(token, pix))
            self._img_thread.start()
        else:
            self.preview.set_image_placeholder("no image")

    def _on_image_fetched(self, token: int, pix) -> None:
        if token != self._hover_token:
            return
        self.preview.set_pixmap(pix)

    # ---------- sort ui ----------

    def update_sort_ui(self) -> None:
        key = self.sort_key
        if key in ("favorite", "custom"):
            self.btn_order.setEnabled(False)
            self.btn_order.setText("降順")
        else:
            self.btn_order.setEnabled(True)
            self.btn_order.setText("降順" if self.sort_desc else "昇順")

        if key == "custom":
            self.list_urls.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
            self.list_urls.setDefaultDropAction(Qt.DropAction.MoveAction)
            self.list_urls.setDragEnabled(True)
            self.list_urls.setAcceptDrops(True)
            self.list_urls.setDropIndicatorShown(True)
            self.lbl_drag_hint.setText("（上下にドラッグして順番を変更 → 自動保存）")
        else:
            self.list_urls.setDragDropMode(QAbstractItemView.DragDropMode.NoDragDrop)
            self.lbl_drag_hint.setText("")

        for i in range(self.cmb_sort.count()):
            if self.cmb_sort.itemData(i) == self.sort_key:
                if self.cmb_sort.currentIndex() != i:
                    self.cmb_sort.setCurrentIndex(i)
                break

    def on_sort_changed(self) -> None:
        self.sort_key = self.cmb_sort.currentData() or "favorite"
        if self.sort_key in ("created_at", "usage_count"):
            self.sort_desc = True
        elif self.sort_key == "url":
            self.sort_desc = False
        else:
            self.sort_desc = True

        self.update_sort_ui()
        self.refresh_list()

    def toggle_sort_order(self) -> None:
        if self.sort_key in ("favorite", "custom"):
            return
        self.sort_desc = not self.sort_desc
        self.update_sort_ui()
        self.refresh_list()

    # ---------- UI events ----------

    def open_excel(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Excelファイルを選択", "", "Excel Files (*.xlsx)")
        if not path:
            return
        try:
            self.repo = ExcelRepository(path)
        except Exception as e:
            QMessageBox.critical(self, "エラー", str(e))
            return

        self.lbl_excel.setText(f"Excel: {path}")
        self.statusBar().showMessage("Excelを読み込みました", 3000)
        self.reload_from_repo()

    def open_tag_manager(self) -> None:
        if not self.ensure_repo():
            return
        dlg = TagManagerDialog(self.repo, self)
        dlg.exec()
        self.reload_from_repo()

    def open_filter(self) -> None:
        if not self.ensure_repo():
            return
        all_tags = sorted(self.repo.load_tags())
        dlg = FilterDialog(all_tags, self.filter_mode, self.filter_tags, self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        self.filter_mode, self.filter_tags = dlg.result_data()
        self.refresh_list()

    def on_search_changed(self, text: str) -> None:
        self.search_text = (text or "").strip().lower()
        self.refresh_list()

    def on_selection_changed(self) -> None:
        has = self.current_item() is not None
        self.btn_edit.setEnabled(has)
        self.btn_delete.setEnabled(has)
        self.btn_go.setEnabled(has)

    def add_url(self) -> None:
        if not self.ensure_repo():
            return
        tags = sorted(self.repo.load_tags())
        dlg = AddEditDialog(tags, title="URLを追加", parent=self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        url, selected_tags = dlg.result_data()
        if not url:
            return

        self.statusBar().showMessage("タイトル/プレビュー取得中…", 3000)
        data = fetch_preview(url)
        title = data.get("title", "")
        desc = data.get("description", "")
        img = data.get("image_url", "")

        try:
            self.repo.add_url(url, selected_tags, title=title, preview_desc=desc, preview_image_url=img)
            self.statusBar().showMessage("Excelに保存しました", 3000)
        except Exception as e:
            QMessageBox.critical(self, "保存エラー", str(e))
            return
        self.reload_from_repo()

    def edit_selected(self) -> None:
        item = self.current_item()
        if not item or not self.ensure_repo():
            return
        tags = sorted(self.repo.load_tags())
        dlg = AddEditDialog(tags, title="URLを編集", initial_url=item.url, initial_tags=item.tags, parent=self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        new_url, new_tags = dlg.result_data()
        if not new_url:
            return
        try:
            self.repo.update_url(item.id, new_url, new_tags)
            self.statusBar().showMessage("タイトル/プレビュー取得中…", 3000)
            data = fetch_preview(new_url)
            self.repo.update_preview(
                item.id,
                title=data.get("title", ""),
                preview_desc=data.get("description", ""),
                preview_image_url=data.get("image_url", ""),
            )
            self.statusBar().showMessage("更新しました", 3000)
        except Exception as e:
            QMessageBox.critical(self, "更新エラー", str(e))
            return
        self.reload_from_repo()

    def delete_selected(self) -> None:
        item = self.current_item()
        if not item or not self.ensure_repo():
            return
        ret = QMessageBox.question(self, "削除確認", "このURLを削除しますか？")
        if ret != QMessageBox.StandardButton.Yes:
            return
        try:
            self.repo.delete_url(item.id)
            self.statusBar().showMessage("削除しました", 3000)
        except Exception as e:
            QMessageBox.critical(self, "削除エラー", str(e))
            return
        self.reload_from_repo()

    def open_selected_in_browser(self) -> None:
        item = self.current_item()
        if not item:
            return
        webbrowser.open(item.url)

        if self.repo is not None:
            try:
                self.repo.increment_usage(item.id)
            except Exception:
                pass
            self.reload_from_repo()

    def show_context_menu(self, pos: QPoint) -> None:
        item = self.current_item()
        if not item:
            return
        menu = QMenu(self)
        act_open = menu.addAction("開く")
        act_edit = menu.addAction("編集")
        act_del = menu.addAction("削除")
        act = menu.exec(self.list_urls.mapToGlobal(pos))
        if act == act_open:
            self.open_selected_in_browser()
        elif act == act_edit:
            self.edit_selected()
        elif act == act_del:
            self.delete_selected()

    # ---------- favorite ----------

    def on_favorite_toggled(self, item_id: str, new_val: int) -> None:
        if not self.ensure_repo():
            return
        try:
            self.repo.set_favorite(item_id, new_val)
            self.statusBar().showMessage("お気に入りを更新しました", 2000)
        except Exception as e:
            QMessageBox.critical(self, "更新エラー", str(e))
        self.reload_from_repo()

    # ---------- custom order ----------

    def on_custom_order_changed(self) -> None:
        if self.sort_key != "custom":
            return
        if not self.ensure_repo():
            return
        ordered_ids: list[str] = []
        for i in range(self.list_urls.count()):
            it = self.list_urls.item(i)
            rid = it.data(Qt.ItemDataRole.UserRole)
            if rid:
                ordered_ids.append(rid)
        try:
            self.repo.set_custom_order(ordered_ids)
            self.statusBar().showMessage("カスタム順を保存しました", 2000)
        except Exception as e:
            QMessageBox.critical(self, "保存エラー", str(e))
            return
        self.reload_from_repo()

    # ---------- Data / rendering ----------

    def ensure_repo(self) -> bool:
        if self.repo is None:
            QMessageBox.information(self, "Excel未選択", "先にExcelファイルを開いてください。")
            return False
        return True

    def reload_from_repo(self) -> None:
        if not self.ensure_repo():
            return
        try:
            self.all_items = self.repo.load_urls()
        except Exception as e:
            QMessageBox.critical(self, "読み込みエラー", str(e))
            self.all_items = []
        self.refresh_list()

    def _apply_sort(self, items: list[UrlItem]) -> list[UrlItem]:
        key = self.sort_key

        if key == "custom":
            return sorted(items, key=lambda it: (it.custom_order, it.created_at))

        if key == "favorite":
            def k(it: UrlItem):
                return (it.favorite, it.created_at, it.usage_count)
            return sorted(items, key=k, reverse=True)

        if key == "created_at":
            return sorted(items, key=lambda it: it.created_at, reverse=self.sort_desc)

        if key == "usage_count":
            return sorted(items, key=lambda it: it.usage_count, reverse=self.sort_desc)

        if key == "url":
            return sorted(items, key=lambda it: it.url.lower(), reverse=self.sort_desc)

        return items

    def refresh_list(self) -> None:
        self.list_urls.clear()

        items = apply_filter(self.all_items, self.filter_tags, self.filter_mode)

        if self.search_text:
            st = self.search_text
            def ok(it: UrlItem) -> bool:
                if st in it.url.lower():
                    return True
                if st in (it.title or "").lower():
                    return True
                return any(st in t.lower() for t in it.tags)
            items = [it for it in items if ok(it)]

        items = self._apply_sort(items)

        if self.filter_tags:
            tags_txt = " ".join(f"#{t}" for t in self.filter_tags)
            self.lbl_filter.setText(f"Filter: {tags_txt} ({self.filter_mode})")
        else:
            self.lbl_filter.setText("Filter: (none)")

        if not items:
            self.list_urls.addItem("(URLがありません)")
            self.on_selection_changed()
            return

        for it in items:
            title = it.title.strip() if it.title else ""
            url_line = self._format_url_line(it)
            date_txt = _format_date(it.created_at)
            meta = f"{date_txt}   利用数: {it.usage_count}" if date_txt else f"利用数: {it.usage_count}"

            lw = QListWidgetItem()
            lw.setData(Qt.ItemDataRole.UserRole, it.id)
            lw.setSizeHint(QSize(0, 78))
            self.list_urls.addItem(lw)

            w = UrlListItemWidget(it.id, title, url_line, meta, bool(it.favorite))
            w.favorite_toggled.connect(self.on_favorite_toggled)
            self.list_urls.setItemWidget(lw, w)

        self.on_selection_changed()

    def current_item(self) -> UrlItem | None:
        cur = self.list_urls.currentItem()
        if not cur:
            return None
        item_id = cur.data(Qt.ItemDataRole.UserRole)
        if not item_id:
            return None
        for it in self.all_items:
            if it.id == item_id:
                return it
        return None

    def _format_url_line(self, it: UrlItem) -> str:
        text = it.url
        if it.tags:
            text += "    " + " ".join(f"#{t}" for t in it.tags)
        return text

    def render_empty_hint(self) -> None:
        self.list_urls.clear()
        self.list_urls.addItem("(Excelを開くとURL一覧が表示されます)")
        self.btn_edit.setEnabled(False)
        self.btn_delete.setEnabled(False)
        self.btn_go.setEnabled(False)
